<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="底板2" tilewidth="32" tileheight="32" tilecount="6675" columns="267">
 <image source="../Texture/底板2.png" width="8552" height="808"/>
</tileset>
