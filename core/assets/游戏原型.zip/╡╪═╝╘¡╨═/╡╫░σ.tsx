<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="ground" tilewidth="32" tileheight="32" tilecount="4525" columns="181">
 <image source="../Texture/底板.png" width="5800" height="808"/>
</tileset>
