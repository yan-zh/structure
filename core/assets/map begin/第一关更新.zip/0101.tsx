<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="0101" tilewidth="32" tileheight="32" tilecount="16170" columns="490">
 <image source="D:/大三上/分组项目/设计/地图素材/地图01/0101.png" width="15680" height="1080"/>
</tileset>
